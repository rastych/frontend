/**
 * Created by IlyaLitvinov on 22.08.16.
 */
(function () {
    angular.module("TodoApp")
        .directive('content', HeaderDirective);

    function HeaderDirective () {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                data: '='
            },
            templateUrl: '/app/directives/content/content.view.html',
            controllerAs: 'vm',
            link: function (scope, elment, attr, ctrl) {
                debugger;
            },
            controller: function ($scope, $filter) {
                var vm = this;
                debugger;
                vm.data = $scope.data;
                vm.$filter = $filter;

                var watcher = $scope.$watch(function () {
                    return $scope.data;
                }, function (newData) {
                    debugger;
                    if( newData.length>0) {
                        debugger;
                        newData = vm.$filter('byDate')(newData);

                        vm.data = vm.$filter('limitTo')(newData, '2');

                        debugger;
                        watcher();
                    }
                })
            }
        }
    }

})();