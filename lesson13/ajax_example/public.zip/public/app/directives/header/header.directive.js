/**
 * Created by IlyaLitvinov on 22.08.16.
 */
(function () {
    angular.module("TodoApp")
        .directive('header', HeaderDirective);

    function HeaderDirective () {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: '/app/directives/header/header.view.html',
            controllerAs: 'directiveCtrl',
            controller: function ($scope) {

            }
        }
    }

})();