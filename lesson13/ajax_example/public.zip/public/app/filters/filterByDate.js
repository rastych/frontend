/**
 * Created by IlyaLitvinov on 22.08.16.
 */
(function () {
    angular.module('TodoApp')
        .filter('byDate', filterByDate);

    function filterByDate() {
        return function (data) {
            return data.sort(function (a, b) {
                if(new Date(a.date).getTime() > new Date(b.date).getTime()) {
                    return -1;
                }

                if(new Date(a.date).getTime() < new Date(b.date).getTime()) {
                    return 1;
                }

                if(new Date(a.date).getTime() === new Date(b.date).getTime()) {
                    return 0;
                }
            });

        }
    }
})();