/**
 * Created by IlyaLitvinov on 22.08.16.
 */
(function () {
    angular.module("TodoApp")
        .controller('mainController', MainController);

    function MainController(appModel, $scope) {
        var vm = this;

        vm.test = "Hello wolrd";
        vm.isEdit = false;
        vm.comments = [];

        vm.newCommentModel = {
            author: null,
            text: null,
            isEdit: false
        };

        // $scope.$watch('vm.comments', function (newData, oldData) {
        //     debugger;
        // });

        appModel.getComments().then(function (response) {
            vm.comments = response;
        });

        vm.addComment = function () {
            var self = this;

            appModel.addComment(angular.copy(vm.newCommentModel))
                .then(function (resp) {
                    vm.comments.push(resp);
                });

            vm.newCommentModel.author = null;
            vm.newCommentModel.text = null;
        };

        vm.edit = function (comment) {
            comment.isEdit = !comment.isEdit;
        };

        vm.editingOff = function (e) {
            if (e.target.classList.contains('edit_input')) {
                e.stopPropagation();
            } else {
                vm.comments.forEach(function (item) {
                    item.isEdit = false;
                })
            }
        };
    }
})();