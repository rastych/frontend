/**
 * Created by IlyaLitvinov on 22.08.16.
 */
(function () {
    angular.module('TodoApp')
        .service('appModel', ModelService);

    function ModelService ($http) {
       this.$http = $http;
    }

    ModelService.prototype.getComments = function () {
        return this.$http({
            method: 'GET',
            url: '/comment'
        }).then(function (resp) {
            return resp.data;
        }, function (e) {
            throw new Error(e.status + ' ' + e.statusText);
        });
    };

    ModelService.prototype.addComment = function (newComment) {
        return this.$http({
            method: 'POST',
            url: '/comment',
            data: newComment
        }).then(function (resp) {
            return resp.data
        },  function (e) {
            throw new Error(e.status + ' ' + e.statusText);
        })
    };

})();